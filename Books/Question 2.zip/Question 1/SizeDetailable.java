public  interface SizeDetailable {
  String getSizeDetails();
}
