import java.io.Serializable;

public  interface SizeDetailable {
  String getSizeDetails();
}
